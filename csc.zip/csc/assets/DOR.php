<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" />

    <title>Daily Output Report</title>

    <link rel="stylesheet" href="../style/DOR.css">
    <link rel="stylesheet" href="../style/DORbar.css">
  
</head>
<body>
  <!--NavBar-->
  <nav>
    <div class="navbar">
      <i class='bx bx-menu'></i>
      <div class="logo"><img src="csc.png" alt=""></div>
      <div class="nav-links">
        <ul class="links">
          <li>
            <a href="DOR.php">DOR</a>
            <i class='bx bxs-chevron-down htmlcss-arrow arrow  '></i>
            <ul class="htmlCss-sub-menu sub-menu">          
              </li>
            </ul>
          <li>
            <a href="MPOR.php">MPOR</a>
            <i class='bx bxs-chevron-down js-arrow arrow '></i>
            <ul class="js-sub-menu sub-menu">
              
            </ul>
          </li>
          <li>
            <a href="SMPOR.php">SMPOR</a>
            <i class='bx bxs-chevron-down js-arrow arrow '></i>
            <ul class="js-sub-menu sub-menu">
              
            </ul>
          </li>
          <li>
            <a href="IPCR.php">IPCR</a>
            <i class='bx bxs-chevron-down js-arrow arrow '></i>
            <ul class="js-sub-menu sub-menu">
              
            </ul>
          </li>
          <li>
            <a href="MPOR(review).php" class="mpor">MPOR (Review)</a>
            <button type="submit" id="Log-out"><a href="logout.php">Log Out</a></button>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!--Table-->
    <div class="container">
      <h6>Daily Output Report</h6>
          <form action="" class="form">
          <h3 class="-h3">Name: <span><?php echo htmlspecialchars($_SESSION["username"]); ?></span>
          <h3 class="h3">Date: <input type="date"></h3>
        <table class="_table">
          <thead>
          </form>
            <tr>
                <th></th>
              <th>Quantity</th>
              <th>Points Per Output</th>
              <th>Output Points</th>
              <th width="50px">
                
              </th>
            </tr>
          </thead>
          <tbody id="table_body">
            <tr>
                <td id="edit" contenteditable="true">
                  aaa
              <td>
                <input type="text" class="form_control">
              </td>
              <td>
                <input type="text" class="form_control" >
              </td>
              <td>
                <input type="text" class="form_control">
              </td>
              <td>
                <div class="action_container">
                  <button class="danger" onclick="remove_tr(this)">
                    <i class="fa fa-close"></i>
                  </button>
                  <button class="success" onclick="create_tr('table_body')">
                    <i class="fa fa-plus"></i>
                  </button>
                </div>
              </td>
            </div>
            </tr>        
      </tbody>

      <!--Total--> 
      <tr>
        <td><h4>TOTAL</h4></td>
        <td></td>
        <td></td>
        <td><input type="text" class="form_control"></td>
      </tr>
      <tr>
        <td><h4>ACTIVITIES DONE</h4></td>
        <td colspan="2"><h4>PERIOD OF TIME</h4></td>
        <td><h4>TOTAL TIME</h4></td>						
      </tr>
      <tr>
        <td></td>
        <td><h4>FROM</h4></td>
        <td><h4>TO</h4></td>
        <td><h5>(In Minutes)</h5></td>
      </tr>
      
      <!--From-To-->
      <tr>
        <td></td>
        <td><input type="text" class="form_control"></td>
        <td><input type="text" class="form_control"></td>
        <td><input type="text" class="form_control"></td>
      </tr>
      <tr>
        <td></td>
        <td><input type="text" class="form_control"></td>
        <td><input type="text" class="form_control"></td>
        <td><input type="text" class="form_control"></td>
      </tr>
      <tr>
        <td></td>
        <td><input type="text" class="form_control"></td>
        <td><input type="text" class="form_control"></td>
        <td><input type="text" class="form_control"></td>
      </tr>
      <tr>
        <td></td>
        <td><input type="text" class="form_control"></td>
        <td><input type="text" class="form_control"></td>
        <td><input type="text" class="form_control"></td>
      </tr>

      <!--Total(in hours and minutes)-->
					<tr>
						<td colspan="3"><h3>TOTAL (in hours minutes)</h3></td>
						<td></td>
					</tr>
					<tr>
						<td colspan="3"><input type="text" class="form_control"></td>
						<td></td>
					</tr>
					<tr>
						<td colspan="3"><h3>TOTAL</h3></td>
						<td></td>
					</tr>
					<tr>
						<td colspan="3"><input type="text" class="form_control"></td>
						<td></td>
					</tr>
        </table>
      </div>

      <!--another table-->
	<div class="wrapper">
		<h5>
			TOTAL WORKING SPEND ON THIS DAY:			
			<input type="input1" name="input1" class="box1">
			<input type="input2" name="input2" class="box2">
		 <p>if working hours are extended past 5 P.M.)</p>		
		</h5>
	</div>

      <!--Table2-->
      <div class="table2">
        <h2>APPOINTMENT DATA</h2>
		<table class="_table-2">
			<thead>
				<tr>
					<th colspan="2"><input type="text" class="form_control1"></th>
				</tr>				
			</thead>
				<tbody>
					<tr>
						<td>A. unacted acts</td>
						<td><input type="text" class="form_control"></td>
					</tr>
					<tr>
						<td>B.acted appts (as of yesterday)</td>
						<td ><input type="text" class="form_control"></td>
					</tr>
					<tr>
						<td>C. acted appts (today)</td>
						<td><input type="text" class="form_control"></td>
					</tr>
					<tr>
						<td>D. total acted appts (b + c)</td>
						<td ><input type="text" class="form_control"></td>
					</tr>
					<tr>
						<td>E. total unacted appts (a - d)</td>
						<td><input type="text" class="form_control"></td>
					</tr>
				</tbody>
			</table>
      </div>

          <!--Table3-->
          <div class="table3">
          <table class="_table-3">
            <thead>
              <tr>
                <th colspan="2"><input type="text" class="form_control1"></th>
              </tr>				
            </thead>
              <tbody>
                <tr>
                  <td>k. appts rec'd</td>
                  <td><input type="text" class="form_control"></td>
                </tr>
                <tr>
                  <td>l. acted appts (as of yesterday)</td>
                  <td ><input type="text" class="form_control"></td>
                </tr>
                <tr>
                  <td>m. acted appts (today)</td>
                  <td><input type="text" class="form_control"></td>
                </tr>
                <tr>
                  <td>n. total acted appts (l + m)</td>
                  <td ><input type="text" class="form_control"></td>
                </tr>
                <tr>
                  <td>o. total unacted appts (k - n)</td>
                  <td><input type="text" class="form_control"></td>
                </tr>
              </tbody>
            </table>
          </div>

          <!--Table4-->
          <div class="table4">
          <table class="_table-4">
            <thead>
              <tr>
                <th colspan="2"><input type="text" class="form_control1"></th>
              </tr>				
            </thead>
              <tbody>
                <tr>
                  <td>f. Total appts rec'd</td>
                  <td><input type="text" class="form_control"></td>
                </tr>
                <tr>
                  <td>g. acted appts (as of yesterday)</td>
                  <td ><input type="text" class="form_control"></td>
                </tr>
                <tr>
                  <td>h. acted appts (today)</td>
                  <td><input type="text" class="form_control"></td>
                </tr>
                <tr>
                  <td>i. total acted appts (g + h)</td>
                  <td ><input type="text" class="form_control"></td>
                </tr>
                <tr>
                  <td>j. total unacted appts (f - i)</td>
                  <td><input type="text" class="form_control"></td>
                </tr>
              </tbody>
            </table>
            </div>

            <!--Table5-->
            <div class="table5">
          <table class="_table-5">
            <thead>
              <tr>
                <th colspan="2"><input type="text" class="form_control1"></th>
              </tr>				
            </thead>
              <tbody>
                <tr>
                  <td>p. total appt rec'd (f + k)</td>
                  <td><input type="text" class="form_control"></td>
                </tr>
                <tr>
                  <td>q. total appts acted as of yesterday (g + l)</td>
                  <td ><input type="text" class="form_control"></td>
                </tr>
                <tr>
                  <td>r. total appts acted today (h + m)</td>
                  <td><input type="text" class="form_control"></td>
                </tr>
                <tr>
                  <td>s. overall total appts acted (q + r)</td>
                  <td ><input type="text" class="form_control"></td>
                </tr>
                <tr>
                  <td>t. overall total unacted appts (j + o)</td>
                  <td><input type="text" class="form_control"></td>
                </tr>
              </tbody>
            </table>
            </div>
            <button class="button" name="submit">Save</button>
            <button class="button1" name="print">Print</button>
    <script src="../DOR.js"></script>
</body>
</html>