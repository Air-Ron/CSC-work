<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IPCR</title>
    <link rel="stylesheet" href="../style/IPCR.css">
    <link rel="stylesheet" href="../style/DORbar.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" />
</head>
<body>
    <!--NavBar-->
  <nav>
    <div class="navbar">
      <i class='bx bx-menu'></i>
      <div class="logo"><img src="csc.png" alt=""></div>
      <div class="nav-links">
        <ul class="links">
          <li>
            <a href="DOR.php">DOR</a>
            <i class='bx bxs-chevron-down htmlcss-arrow arrow  '></i>
            <ul class="htmlCss-sub-menu sub-menu">
                          
              </li>
            </ul>
          <li>
            <a href="MPOR.php">MPOR</a>
            <i class='bx bxs-chevron-down js-arrow arrow '></i>
            <ul class="js-sub-menu sub-menu">
              
            </ul>
          </li>
          <li>
            <a href="SMPOR.php">SMPOR</a>
            <i class='bx bxs-chevron-down js-arrow arrow '></i>
            <ul class="js-sub-menu sub-menu">
             
            </ul>
          </li>
          <li>
            <a href="IPCR.php">IPCR</a>
            <i class='bx bxs-chevron-down js-arrow arrow '></i>
            <ul class="js-sub-menu sub-menu">
              
            </ul>
          </li>
          <li>
            <a href="MPOR(review).php">MPOR (Review)</a>
            <button type="submit" id="Log-out"><a href="logout.php">Log Out</a></button>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="wrapper_2">
  <table border="1px" cellspacing="0" align="center" height="50" width="1400">

        <tr>
        <th >INDIVIDUAL PERFORMANCE COMMITMENT AND REVIEW (IPCR)</th>
        </table>
    </tr>
    
    <table border="1px" cellspacing="0" align="center" height="50" width="1400">
    
            <tr>
        <th contenteditable="true">I, HANNAH JOY B. PELLETERO, Job Order of Civil Service Commission, Davao del Sur Field Office, commit to deliver and agree to be rated on the attainment of the following targets in accordance with the indicated measures for the period July to December 2021</th>
            </tr>
        
    </table>
        <table  border="1px" cellspacing="0" align="center" height="20" width="1400">
            
                <tr>
                <th style="padding-top: 10px;" class="th"><h2><?php echo htmlspecialchars($_SESSION["username"]); ?></h2>
                 <h2 >Job Order <form action="" class="form">
                    <h2>Date: <input type="Date" name="Month of">
                    </form>
                </th>
         </tr>
    
 </table>
        <table border="1px" cellspacing="0" align="center" height=" 20" width="1400">
         
    <tr>
        <th >Reviewed by: <p>RICHARD T. ORTIZ</p> <p >Director II</p> <p >Immediate Supervisor</p></th>
        <th ><form action="" class="form"></form><input type="DATE" name="DATE"></form></th>
        <th >Approved by: <p>ADAMS D. TORRES, CESO VI</p> <p >Director IV</p> <p >Head Of Office</p></th>
        <th><input type="date" name="rj"></th>
    </tr>
    </table>
        <table border="1px" cellspacing="0" align="center" height="20" width="1400">
            <tr>
                <th rowspan="2" >Output</th>
                <th rowspan="2">Success Indicator Target+Measure</th>
                <th rowspan="2">Actual Accomplishments</th>
                <th colspan="4"></th>
                <th rowspan="2">Remarks</th>
            </tr>
            <tr>
                <th >E</th>
                <th >Q</th>
                <th >T</th>
                <th >A</th>
            </tr>
            <tr>
                <th>Core Functions (80%)</th>
            </tr>
            <tr>
            <th align="left" >EUN codes attached to 201 folder</th>
            <th align="justify" >100% EUN codes attached to 201 folders with no error.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left">Support Functions (20%)</th>
        </tr>
        <tr>
            <th align="left" >Daily Output Report Submitted</th>
            <th align="justify" >100% of Daily Output Reports submitted without error at end of every working day.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left" >S-Cards Updated (old)</th>
            <th align="justify" >100% of existing records updated on S-card without error within the day from instruction(piecemeal), or a month before semester ends (bulk, as in NOSA).</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left" >Documents Received (Per Stamp)</th>
            <th align="justify" >100% of documents rubber-stamp received without error within 15 minutes after receipt (for piecemeal documents).</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left" >Non-201 documents filed</th>
            <th align="justify" >100% of Non-201 documents filed with no error a day after inspection.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left" >Letters Prepared</th>
            <th align="justify" >100% of letters prepared with no error within 1 WD after instruction.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left" >Minutes of Meetings Prepared</th>
            <th align="justify" >100% of minutes of assigned FO staff meetings prepared without revision within 10 WDs after the meeting.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left" >EOBD ID Code Done</th>
            <th align="justify" >100% of EOBD ID Code Done with no error within a day from recept of appointment.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left">MPOR Submitted</th>
            <th align="justify" >6/6 MPORs submitted with no error on the prescribed deadline.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left">SMPOR Submitted</th>
            <th align="justify" >1/1 SMPOR submitted with no error on the prescribed deadline.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left">IPCR Submitted</th>
            <th align="justify" >1/1 IPCR submitted with no error on the prescribed deadline.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left">Purchase Requests (PR) Prepared</th>
            <th align="justify" >100% of Purchase Requests prepared with no error within a day from instruction.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left">Requisition and Issuance Slips (RIS) Prepared</th>
            <th align="justify" >100% of Requisition and Issuance Slips prepared with no error within a day from instruction.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left">Supplies monitor cards updated</th>
            <th align="justify" >6/6 supplies monitor cards updated with no error within a day after receipt of supplies.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left">Cleaning in the Kitchen Done</th>
            <th align="justify" >100% of cleaning in the kitchen done.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left">Washing dishes</th>
            <th align="justify" >22/22 or 100% of washing dishes done.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left" >DTR Submitted</th>
            <th align="justify" >6/6 DTRs submitted with no error a day after 15th and last WD of the month.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left" >RBPMS</th>
            <th align="justify" >Six RBPMS sheets submitted with no error on the prescribed deadline.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left" >Verification for License/Eligibility Requested</th>
            <th align="justify" >100% of requests for verification of eligibility prepared without error within a month from receipt of appointment.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left" >Flag Ceremonies Attended</th>
            <th align="justify" >100% of flag raising and lowering ceremonies attended.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left" >Health and Wellness Activities Prepared</th>
            <th align="justify" >100% of health and wellness activities participated in.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
        <tr>
            <th align="left" >Area Maintenance</th>
            <th align="justify">100% of maintenance of area with no negative feedback done.</th>
            <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
            <th><input type="text" name="num1"></th>
        </tr>
            <table border="1px" cellspacing="0" align="center" height="20" width="1400">
                <tr>
                    <th align="left">Final Average Rating</th>
                </tr>
                <tr>
                    <th align="left">Comments and Recommendations for Development Purposes</th>
                </tr>
                <tr>
                    <th><textarea name="" id="my-text1" cols="" rows="4"></textarea></th>
                </tr>
            </table>
        <table  border="1px" cellspacing="0" align="center" height="10" width="1400">
            <tr>
                <th rowspan="2">Output</th>
                <th rowspan="2">Success Indicator Target+Measure</th>
                <th rowspan="2">Actual Accomplishments</th>
                <th colspan="4"></th>
                <th rowspan="2" >Remarks</th>
            </tr>
            <tr>
                <th >E</th>
                <th >Q</th>
                <th >T</th>
                <th >A</th>
            </tr>
            <tr>
                <th align= "left">Category</th>
                <th>MFO</th>
                <th>Rating</th>
                <th> </th>
                <th> </th>
                <th> </th>
                <th> </th>
                <th> </th>
                
            </tr>
            <tr>
                <th align= "left" >Core Functions</th>
                
                
            </tr>
            <tr>
                <th align= "left" >Strategic Objectives</th>
                <th><input type="text" name="num1"></th>
                <th><input type="text" name="num1"></th>
                <th><input type="text" name="num1"></th>
                <th><input type="text" name="num1"></th>
                <th><input type="text" name="num1"></th>
                <th><input type="text" name="num1"></th>
                <th><input type="text" name="num1"></th>               
            </tr>
            <tr>
                <th align= "left" >Support Functions</th>
                <th><input type="text" name="num1"></th>
                <th><input type="text" name="num1"></th>      
            </tr>
            <tr>
                <th align= "left" >Total/Final overall Rating</th>
                <th><input type="text" name="num1"></th>
                <th><input type="text" name="num1"></th>      
            </tr>
            <tr>
                <th align= "left" >Adjectival Rating</th>
                <th><input type="text" name="num1"></th>      
                <th><textarea name="" id="my-text2" cols="" rows="4"></textarea></th>
            </tr>
                <table border="1px" cellspacing="0" align="center" height="10" width="1400">
                    <tr>
                        <th align= "left" >Discussed with:</th>
                        <th align= "left" >Date</th>
                        <th align= "left" >Assessed by:</th>
                        <th align= "left" >Date</th>
                        <th align= "left" >Final Rating by:</th>
                        <th align= "left" >Date</th>
                    </tr>
                    <tr>
                        <th><?php echo htmlspecialchars($_SESSION["username"]); ?></th>
                        <th><input type="date" name="DATE"></th>
                        <th>RICHARD T. ORTIZ</th>
                        <th><input type="date" name="DATE"></th>
                        <th>ADAMS D. TORRES</th>
                        <th><input type="date" name="DATE"></th>
                    </tr>
                    <tr>
                        <th >Government Internship Program</th>
                        <th> </th>
                        <th >Director III</th>
                        <th> </th>
                        <th >Director IV</th>
                    </tr>
                </table>
        </table>
        </table>
    </div>
    <button class="btn" name="submit">Save</button>
    <button class="btn1" name="Print">Print</button>     
</body>
</php>