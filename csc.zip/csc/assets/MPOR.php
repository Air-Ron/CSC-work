<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
<head>
    <meta charset="UTF-8">
    <title>MONTHLY PERFORMANCE OUTPUT REPORT</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="../style/MPOR.css">
    <link rel="stylesheet" href="../style/DORbar.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" />
    <script src="../cash.js"></script>
    <script src="../MPOR.js"></script>
   
    <script src="../MPORadddelete.js"></script>
</head>
<body>
    <!--NavBar-->
    <nav>
        <div class="navbar">
          <i class='bx bx-menu'></i>
          <div class="logo"><img src="csc.png" alt=""></div>
          <div class="nav-links">
            <ul class="links">
              <li>
                <a href="DOR.php">DOR</a>
                <i class='bx bxs-chevron-down htmlcss-arrow arrow  '></i>
                <ul class="htmlCss-sub-menu sub-menu">
                              
                  </li>
                </ul>
              <li>
                <a href="MPOR.php">MPOR</a>
                <i class='bx bxs-chevron-down js-arrow arrow '></i>
                <ul class="js-sub-menu sub-menu">
                  
                </ul>
              </li>
              <li>
                <a href="SMPOR.php">SMPOR</a>
                <i class='bx bxs-chevron-down js-arrow arrow '></i>
                <ul class="js-sub-menu sub-menu">
                  
                </ul>
              </li>
              <li>
                <a href="IPCR.php">IPCR</a>
                <i class='bx bxs-chevron-down js-arrow arrow '></i>
                <ul class="js-sub-menu sub-menu">
                  
                </ul>
              </li>
              <li>
                <a href="MPOR(review).php">MPOR (Review)</a>
                <button type="submit" id="Log-out"><a href="logout.php" class="a">Log Out</a></button>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    <div class="wrapper">
    <table id="table-1" border="1px" cellspacing="0" align="center" height="800" width="1400">
        <tr>
            <th colspan="16">Republic of the Philippines <p>Civil Service Commission</p> <p>Davao del Sur Field Office</p></th>
        </tr>
        <tr>
            <th class="name"colspan="16"><h2>MONTHLY PERFORMANCE OUTPUT REPORT</h2>
            <form action="" class="form">    
            <h3>Name: <?php echo htmlspecialchars($_SESSION["username"]); ?></h3>
             <h3>Month: <input type="month" id="hut"></h3>
            </form>
            </th>
            
        </tr>
        <tr>
            <th rowspan="3">EXPECTED OUTPUTS</th>
            <th colspan="5">EFFICIENCY</th>
            <th colspan="5">QUALITY</th>
            <th colspan="5">TIMELINESS</th>
        </tr>
        <tr>
            <th colspan="4">WEEK</th>
            <th rowspan="2">TOTAL</th>
            <th colspan="4">WEEK </th>
            <th rowspan="2">TOTAL</th>
            <th colspan="4">WEEK</th>
            <th rowspan="2">TOTAL</th>
        </tr>
        <tr>
            <th>1</th>
            <th>2</th>
            <th>3</th>
            <th>4</th>          
            <th>1</th>
            <th>2</th>
            <th>3</th>
            <th>4</th>          
            <th>1</th>
            <th>2</th>
            <th>3</th>
            <th>4</th>
        </tr>
        <tr>
            <div class="core"><th align="left" class="core">CORE FUNCTION</th>
            <th class="core"></th>
            <th class="core"> </th>
            <th class="core"> </th>
            <th class="core"> </th>          
            <th class="core"> </th>
            <th class="core"> </th>
            <th class="core"> </th>
            <th class="core"> </th>          
            <th class="core"> </th>
            <th class="core"> </th>
            <th class="core"> </th>
            <th class="core"> </th>
            <th class="core"> </th>
            <th class="core"> </th>
            <th class="core"> </th>
        </div>
        </tr>
        <tbody id="table_body">
        <tr>
            <th align="left">EUN codes attached to 201 folder</th>
            <th><input type="text" id="text1" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="text2" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="text3" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="text4" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result"name="num5.1"></th>
            <th><input type="text" id="text5" name="num5" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="text6" name="num6" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="text7" name="num7" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="text8" name="num8" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result1"name="num9"></th>
            <th><input type="text" id="textq" name="numq" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="textw" name="numw" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="texte" name="nume" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="textr" name="numr" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result2"name="numt"></th>
            
        </tr>
    </tbody>
        <tr>
            <div class="support"><th align="left" class="support">SUPPORT FUNCTIONS</th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>          
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>          
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
        </div> 
        </tr>
        <tbody id="table_body1">
        <tr>
            <th align="left">Daily Output Report Submitted</th>
            <th><input type="text" id="t" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="te" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="tex" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="textt" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result3"name="num5.1"></th>
            <th><input type="text" id="texx" name="num5" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="tee" name="num6" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="teex" name="num7" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="texxt" name="num8" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result4"name="num9"></th>
            <th><input type="text" id="texta" name="numq" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="texts" name="numw" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="textd" name="nume" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="textf" name="numr" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result5"name="numt"></th>
            
        </tr>
    </tbody>
        <tr>
            <th align="left">Letters prepared</th>
            <th><input type="text" id="tttt" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="eeee" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="xxxx" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="qqqq" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result6"name="num5.1"></th>
            <th><input type="text" id="1111" name="num5" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2222" name="num6" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3333" name="num7" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4444" name="num8" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result7"name="num9"></th>
            <th><input type="text" id="1" name="numq" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2" name="numw" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3" name="nume" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4" name="numr" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result8"name="numt"></th>
            
        </tr>
        <tr>
            <th align="left">Scards updated (NOSA)</th>
            <th><input type="text" id="11" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="22" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="33" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="44" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result9"name="num5.1"></th>
            <th><input type="text" id="111" name="num5" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="222" name="num6" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="333" name="num7" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="444" name="num8" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resultt"name="num9"></th>
            <th><input type="text" id="12" name="numq" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="23" name="numw" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="34" name="nume" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="45" name="numr" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resultt1"name="numt"></th>
            
        </tr>
        <tr>
            <th align="left">Documents Received (Per sheet stamped)</th>
            <th><input type="text" id="1.1" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2.2" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3.3" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4.4" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resultt2"name="num5.1"></th>
            <th><input type="text" id="11.1" name="num5" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="22.2" name="num6" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="33.3" name="num7" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="44.4" name="num8" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resultt3"name="num9"></th>
            <th><input type="text" id="1.2" name="numq" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2.3" name="numw" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3.4" name="nume" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4.5" name="numr" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resultt4"name="numt"></th>
           
        </tr>
        <tr>
            <th align="left">RIS prepared</th>
            <th><input type="text" id="1.11" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2.22" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3.33" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4.44" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resultt5"name="num5.1"></th>
            <th><input type="text" id="11.11" name="num5" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="22.22" name="num6" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="33.33" name="num7" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="44.44" name="num8" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resultt6"name="num9"></th>
            <th><input type="text" id="1.22" name="numq" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2.33" name="numw" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3.44" name="nume" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4.55" name="numr" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resultt7"name="numt"></th>
            
        </tr>
        <tr>
            <th align="left">DTR Submitted</th>
            <th><input type="text" id="1.111" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2.222" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3.333" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4.444" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resultt8"name="num5.1"></th>
            <th><input type="text" id="12.11" name="num5" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="23.22" name="num6" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="34.33" name="num7" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="45.44" name="num8" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resultt9"name="num9"></th>
            <th><input type="text" id="1.222" name="numq" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2.333" name="numw" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3.444" name="nume" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4.555" name="numr" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resullt"name="numt"></th>
            
        </tr>
        <tr>
            <th align="left">MPOR Submitted</th>
            <th><input type="text" id="a" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="b" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="c" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="d" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resullt1"name="num5.1"></th>
            <th><input type="text" id="e" name="num5" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="f" name="num6" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="g" name="num7" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="h" name="num8" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resullt2"name="num9"></th>
            <th><input type="text" id="i" name="numq" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="j" name="numw" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="k" name="nume" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="l" name="numr" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resullt3"name="numt"></th>
            
        </tr>
        <tr>
            <th align="left">RBPMS Submitted</th>
            <th><input type="text" id="a1" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="b2" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="c3" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="d4" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resullt4"name="num5.1"></th>
            <th><input type="text" id="e1" name="num5" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="f2" name="num6" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="g3" name="num7" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="h4" name="num8" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resullt5"name="num9"></th>
            <th><input type="text" id="i1" name="numq" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="j2" name="numw" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="k3" name="nume" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="l4" name="numr" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resullt6"name="numt"></th>
            
        </tr>
        <tr>
            <th align="left">SMPOR Submitted</th>
            <th><input type="text" id="a11" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="b22" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="c33" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="d44" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resullt7"name="num5.1"></th>
            <th><input type="text" id="e11" name="num5" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="f22" name="num6" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="g33" name="num7" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="h44" name="num8" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resullt8"name="num9"></th>
            <th><input type="text" id="i11" name="numq" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="j22" name="numw" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="k33" name="nume" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="l44" name="numr" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resullt9"name="numt"></th>
            
        </tr>
        <tr>
            <th align="left">Minutes Prepared</th>
            <th><input type="text" id="a1.1" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="b2.2" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="c3.3" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="d4.4" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resulltt"name="num5.1"></th>
            <th><input type="text" id="e1.1" name="num5" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="f2.2" name="num6" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="g3.3" name="num7" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="h4.4" name="num8" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resulltt1"name="num9"></th>
            <th><input type="text" id="i1.1" name="numq" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="j2.2" name="numw" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="k3.3" name="nume" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="l4.4" name="numr" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resulltt2"name="numt"></th>
            
        </tr>
        <tr>
            <th align="left">Documents encoded and printed</th>
            <th><input type="text" id="a1.11" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="b2.22" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="c3.33" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="d4.44" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resulltt3"name="num5.1"></th>
            <th><input type="text" id="e1.11" name="num5" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="f2.22" name="num6" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="g3.33" name="num7" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="h4.44" name="num8" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resulltt4"name="num9"></th>
            <th><input type="text" id="i1.11" name="numq" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="j2.22" name="numw" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="k3.33" name="nume" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="l4.44" name="numr" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resulltt5"name="numt"></th>
            
        </tr>
        <tr>
            <th align="left">Documents Filed (Non 201 and ISO File)</th>
            <th><input type="text" id="a11.11" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="b22.22" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="c33.33" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="d44.44" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resulltt6"name="num5.1"></th>
            <th><input type="text" id="e11.11" name="num5" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="f22.22" name="num6" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="g33.33" name="num7" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="h44.44" name="num8" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resulltt7"name="num9"></th>
            <th><input type="text" id="i11.11" name="numq" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="j22.22" name="numw" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="k33.33" name="nume" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="l44.44" name="numr" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resulltt8"name="numt"></th>
            
        </tr>
        <tr>
            <th align="left">Folder Tag(Non-201 Files for 2022)</th>
            <th><input type="text" id="m" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="n" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="o" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="p" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="resulltt9"name="num5.1"></th>
            <th><input type="text" id="q" name="num5" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="r" name="num6" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="s" name="num7" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="y" name="num8" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total"name="num9"></th>
            <th><input type="text" id="u" name="numq" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="v" name="numw" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="w" name="nume" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="x" name="numr" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total1"name="numt"></th>
            
        </tr>
        <tr>
            <th align="left">EOBD ID Code Nos. Done</th>
            <th><input type="text" id="m1" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="n2" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="o3" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="p4" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total2"name="num5.1"></th>
            <th><input type="text" id="q1" name="num5" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="r2" name="num6" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="s3" name="num7" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t4" name="num8" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total3"name="num9"></th>
            <th><input type="text" id="u1" name="numq" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="v2" name="numw" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="w3" name="nume" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="x4" name="numr" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total4"name="numt"></th>
            
        </tr>
        <tr>
            <th align="left">Washing of Dishes Done</th>
            <th><input type="text" id="m11" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="n22" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="o33" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="p44" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total5"name="num5.1"></th>
            <th><input type="text" id="q11" name="num5" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="r22" name="num6" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="s33" name="num7" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t44" name="num8" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total6"name="num9"></th>
            <th><input type="text" id="u11" name="numq" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="v22" name="numw" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="w33" name="nume" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="x44" name="numr" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total7"name="numt"></th>
            
        </tr>
    </table>
        
        <table border = "1px"cellspacing="0" align="center" height="150" width="1400">
            <tr>
                <th></th>
                <th>WEEK1</th>
                <th>WEEK2</th>
                <th>WEEK3</th>
                <tH>WEEK4</tH>
                <th>TOTAL</th>
            </tr>
            <tr>
                <th align="left">MAN DAY(S) LOST THRU ABSENCE</th>
                <th><input type="text" name="num1"></th>
                <th><input type="text" name="num1"></th>
                <th><input type="text" name="num1"></th>
                <th><input type="text" name="num1"></th>
                <th><input type="text" name="num1"></th>
            </tr>
            <tr>
                <th align="left">MAN HRS./MINUTES LOST THRU TARDINESS UNDERTIME</th>
                <th><input type="text" name="num1"></th>
                <th><input type="text" name="num1"></th>
                <th><input type="text" name="num1"></th>
                <th><input type="text" name="num1"></th>
                <th><input type="text" name="num1"></th>
            </tr>
        </table>

            <table border="1px" cellspacing="0" align="center" height="50">
                <tr>
                    <th align="left">OBSERVATION/REMARKS:</th>
                    <th><textarea name="" id="my-text" cols="" rows="4"></textarea></th>
                </tr>
            </table>
                <table border="1px" cellspacing="0" align="center" height="50">
            <tr>
           
                <th align="left" >CONFIRMED: <p align="center">RICHARD T. ORTIZ</p> <p align="center">Director II</p></th>            
                <th ><form action="" class="form"><input type="date" id="asd" name="txt"></form></th>
                <th ><?php echo htmlspecialchars($_SESSION["username"]); ?><p>GIP</p></th>           
                <th><form action="" class="form"><input type="date" id="asd" name="txt"></form></th>
            </form>
            </tr>
        </table>     
    </table>
</div>
    <button class="btn" name="submit">Save</button>
    <button class="btn1" name="print">Print</button>
</body>
