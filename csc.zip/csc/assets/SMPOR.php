<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMPOR</title>
    <link rel="stylesheet" href="../style/SMPOR.css">
    <link rel="stylesheet" href="../style/DORbar.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" />
    <script src="../SMPOR.js"></script>
</head>
<body>
    <!--NavBar-->
  <nav>
    <div class="navbar">
      <i class='bx bx-menu'></i>
      <div class="logo"><img src="csc.png" alt=""></div>
      <div class="nav-links">
        <ul class="links">
          <li>
            <a href="DOR.php">DOR</a>
            <i class='bx bxs-chevron-down htmlcss-arrow arrow  '></i>
            <ul class="htmlCss-sub-menu sub-menu">
                          
              </li>
            </ul>
          <li>
            <a href="MPOR.php">MPOR</a>
            <i class='bx bxs-chevron-down js-arrow arrow '></i>
            <ul class="js-sub-menu sub-menu">
              
            </ul>
          </li>
          <li>
            <a href="SMPOR.php">SMPOR</a>
            <i class='bx bxs-chevron-down js-arrow arrow '></i>
            <ul class="js-sub-menu sub-menu">
              
            </ul>
          </li>
          <li>
            <a href="IPCR.php">IPCR</a>
            <i class='bx bxs-chevron-down js-arrow arrow '></i>
            <ul class="js-sub-menu sub-menu">
              
            </ul>
          </li>
          <li>
            <a href="MPOR(review).php">MPOR (Review) 
              <button type="submit" id="Log-out"><a href="logout.php">Log Out</a></button>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="wrapper_1">
    <table border="1px" cellspacing="0" align="center" height="800" width="1500">
        <tr>
            <th colspan="24"><p> Republic of the Philippines</p>
              <p>Civil Service Commission</p> 
              <p>Davao del Sur Field Office</p></th>
        </tr>
        
        <tr>
            <th class="name"colspan="24"><h2>SUMMARY OF MONTHLY PERFORMANCE OUTPUT REPORT</h2> 
              <form action="" class="form">
              <h3>Name: <?php echo htmlspecialchars($_SESSION["username"]); ?></h3> 
            <h3>Month <input type="month" class="month"></h3>
          </form>
            </th>
           
            
        </tr>
        <tr>
            <th rowspan="3">EXPECTED OUTPUTS</th>
            <th colspan="7">EFFICIENCY</th>
            <th colspan="7">QUALITY</th>
            <th colspan="7">TIMELINESS</th>
        </tr>
        <tr>
            <th colspan="6">MONTH</th>
            <th rowspan="2">TOTAL</th>
            <th colspan="6">MONTH</th>
            <th rowspan="2">TOTAL</th>
            <th rowspan="2">AVERAGE</th>
            <th colspan="6">MONTH</th>
            <th rowspan="2">TOTAL</th>
            <th rowspan="2">AVERAGE</th>
        </tr>   
        <tr>
            <th>JAN</th>
            <th>FEB</th>
            <th>MAR</th>
            <th>APR</th>
            <th>MAY</th>
            <th>JUNE</th>
            <th>JAN</th>
            <th>FEB</th>
            <th>MAR</th>
            <th>APR</th>
            <th>MAY</th>
            <th>JUNE</th> 
            <th>JAN</th>
            <th>FEB</th>
            <th>MAR</th>
            <th>APR</th>
            <th>MAY</th>
            <th>JUNE</th>           
        </tr>
        <tr>
          <div class="support"><th align="left" class="support">CORE FUNCTION</th>
            <th class="support"></th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>          
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>          
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
            <th class="support"> </th>
        </div>
        </tr>
        <tr>
            <th align="left">EUN codes attached to 201 folder</th>
            <th><input type="text" id="text1" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="text2" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="text3" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="text4" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="text5" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="text6" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result"name="num5"></th>
            <th><input type="text" id="text11" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="text22" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="text33" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="text44" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="text55" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="text66" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result1"name="num5"></th>
            <th><input type="text" id="average"name="num5"></th>
            <th><input type="text" id="textt1" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="textt2" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="textt3" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="textt4" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="textt5" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="textt6" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result2"name="num5"></th>
            <th><input type="text" id="result2.1"name="num5"></th>      
        </tr>
        <tr> <div class="support"><th align="left" class="support">SUPPORT FUNCTION</th>
          <th class="support"></th>
          <th class="support"> </th>
          <th class="support"> </th>
          <th class="support"> </th>          
          <th class="support"> </th>
          <th class="support"> </th>
          <th class="support"> </th>
          <th class="support"> </th>          
          <th class="support"> </th>
          <th class="support"> </th>
          <th class="support"> </th>
          <th class="support"> </th>
          <th class="support"> </th>
          <th class="support"> </th>
          <th class="support"> </th>
          <th class="support"> </th>
          <th class="support"> </th>
          <th class="support"> </th>
          <th class="support"> </th>
          <th class="support"> </th>
          <th class="support"> </th>
          <th class="support"> </th>
          <th class="support"> </th>
        </tr>
        <tr>
            <th align="left">Daily Output Report Submitted</th>
            <th><input type="text" id="1" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result3"name="num5"></th>
            <th><input type="text" id="11" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="22" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="33" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="44" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="55" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="66" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result4"name="num5"></th>
            <th><input type="text" id="result4.1"name="num5"></th>
            <th><input type="text" id="t1" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t2" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t3" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t4" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t5" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t6" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result5"name="num5"></th>
            <th><input type="text" id="result5.1"name="num5"></th>      
        </tr>
        <tr>
            <th align="left">Letters prepared</th>
            <th><input type="text" id="12" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="23" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="34" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="45" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="56" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="67" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result6"name="num5"></th>
            <th><input type="text" id="112" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="223" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="334" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="445" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="556" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="667" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result7"name="num5"></th>
            <th><input type="text" id="result7.1"name="num5"></th>
            <th><input type="text" id="t11" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t22" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t33" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t44" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t55" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t66" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result8"name="num5"></th>
            <th><input type="text" id="result8.1"name="num5"></th>      
        </tr>
        <tr>
            <th align="left">Scards updated (NOSA)</th>
            <th><input type="text" id="122" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="233" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="344" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="455" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="566" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="677" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result9"name="num5"></th>
            <th><input type="text" id="11.2" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="22.3" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="33.4" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="44.5" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="55.6" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="66.7" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result0"name="num5"></th>
            <th><input type="text" id="result0.1"name="num5"></th>
            <th><input type="text" id="t1.1" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t2.2" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t3.3" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t4.4" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t5.5" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t6.6" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result01"name="num5"></th>
            <th><input type="text" id="result01.1"name="num5"></th>      
        </tr>
        <tr>
            <th align="left">Documents Received (Per sheet stamped)</th>
            <th><input type="text" id="12.2" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="23.3" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="34.4" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="45.5" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="56.6" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="67.7" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result02"name="num5"></th>
            <th><input type="text" id="11.22" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="22.33" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="33.44" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="44.55" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="55.66" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="66.77" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result03"name="num5"></th>
            <th><input type="text" id="result0.3"name="num5"></th>
            <th><input type="text" id="t1.11" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t2.22" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t3.33" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t4.44" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t5.55" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t6.66" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result04"name="num5"></th>
            <th><input type="text" id="result01.4"name="num5"></th>     
        </tr>
        <tr>
            <th align="left">RIS prepared</th>
            <th><input type="text" id="12.21" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="23.32" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="34.43" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="45.54" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="56.65" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="67.76" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result05"name="num5"></th>
            <th><input type="text" id="11.221" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="22.332" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="33.443" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="44.554" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="55.665" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="66.776" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result06"name="num5"></th>
            <th><input type="text" id="result0.6"name="num5"></th>
            <th><input type="text" id="t1.111" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t2.222" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t3.333" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t4.444" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t5.555" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="t6.666" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result07"name="num5"></th>
            <th><input type="text" id="result01.7"name="num5"></th>  
        </tr>
        <tr>
            <th align="left">DTR Submitted</th>
            <th><input type="text" id="1a" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2a" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3a" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4a" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5a" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6a" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result08"name="num5"></th>
            <th><input type="text" id="1b" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2b" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3b" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4b" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5b" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6b" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="result09"name="num5"></th>
            <th><input type="text" id="result9.1"name="num5"></th>
            <th><input type="text" id="1c" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2c" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3c" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4c" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5c" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6c" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total"name="num5"></th>
            <th><input type="text" id="total.1"name="num5"></th>      
        </tr>
        <tr>
            <th align="left">MPOR Submitted</th>
            <th><input type="text" id="1a1" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2a1" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3a1" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4a1" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5a1" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6a1" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total2"name="num5"></th>
            <th><input type="text" id="1b1" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2b1" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3b1" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4b1" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5b1" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6b1" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total3"name="num5"></th>
            <th><input type="text" id="total.3"name="num5"></th>
            <th><input type="text" id="1c1" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2c1" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3c1" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4c1" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5c1" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6c1" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total4"name="num5"></th>
            <th><input type="text" id="total.4"name="num5"></th>      
        </tr>
        <tr>
            <th align="left">RBPMS Submitted</th>
            <th><input type="text" id="1a2" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2a2" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3a2" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4a2" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5a2" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6a2" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total5"name="num5"></th>
            <th><input type="text" id="1b2" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2b2" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3b2" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4b2" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5b2" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6b2" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total6"name="num5"></th>
            <th><input type="text" id="total.6"name="num5"></th>
            <th><input type="text" id="1c2" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2c2" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3c2" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4c2" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5c2" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6c2" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total7"name="num5"></th>
            <th><input type="text" id="total.7"name="num5"></th>     
        </tr>
        <tr>
            <th align="left">SMPOR Submitted</th>
            <th><input type="text" id="1a3" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2a3" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3a3" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4a3" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5a3" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6a3" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total8"name="num5"></th>
            <th><input type="text" id="1b3" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2b3" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3b3" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4b3" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5b3" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6b3" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total9"name="num5"></th>
            <th><input type="text" id="total.9"name="num5"></th>
            <th><input type="text" id="1c3" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2c3" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3c3" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4c3" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5c3" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6c3" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total11"name="num5"></th>
            <th><input type="text" id="total.11"name="num5"></th>     
        </tr>
        </tr>
        <tr>
            <th align="left">Minutes Prepared</th>
            <th><input type="text" id="1a4" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2a4" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3a4" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4a4" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5a4" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6a4" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total12"name="num5"></th>
            <th><input type="text" id="1b4" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2b4" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3b4" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4b4" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5b4" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6b4" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total13"name="num5"></th>
            <th><input type="text" id="total.13"name="num5"></th>
            <th><input type="text" id="1c4" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2c4" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3c4" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4c4" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5c4" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6c4" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total14"name="num5"></th>
            <th><input type="text" id="total.14"name="num5"></th>     
        </tr>
        <tr>
            <th align="left">Documents encoded and printed</th>
            <th><input type="text" id="1a5" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2a5" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3a5" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4a5" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5a5" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6a5" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total15"name="num5"></th>
            <th><input type="text" id="1b5" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2b5" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3b5" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4b5" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5b5" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6b5" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total16"name="num5"></th>
            <th><input type="text" id="total.16"name="num5"></th>
            <th><input type="text" id="1c5" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2c5" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3c5" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4c5" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5c5" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6c5" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total17"name="num5"></th>
            <th><input type="text" id="total.17"name="num5"></th>
        </tr>
        <tr>
            <th align="left">Documents Filed (Non 201 and ISO File)</th>
            <th><input type="text" id="1a6" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2a6" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3a6" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4a6" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5a6" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6a6" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total18"name="num5"></th>
            <th><input type="text" id="1b6" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2b6" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3b6" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4b6" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5b6" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6b6" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total19"name="num5"></th>
            <th><input type="text" id="total.19"name="num5"></th>
            <th><input type="text" id="1c6" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2c6" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3c6" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4c6" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5c6" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6c6" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total20"name="num5"></th>
            <th><input type="text" id="total.20"name="num5"></th>
        </tr>
        <tr>
            <th align="left">Folder Tag(Non-201 Files for 2022)</th>
            <th><input type="text" id="1a7" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2a7" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3a7" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4a7" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5a7" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6a7" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total21"name="num5"></th>
            <th><input type="text" id="1b7" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2b7" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3b7" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4b7" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5b7" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6b7" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total22"name="num5"></th>
            <th><input type="text" id="total.22"name="num5"></th>
            <th><input type="text" id="1c7" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2c7" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3c7" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4c7" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5c7" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6c7" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total23"name="num5"></th>
            <th><input type="text" id="total.23"name="num5"></th>
        </tr>
        <tr>
            <th align="left">EOBD ID Code Nos. Done</th>
            <th><input type="text" id="1a8" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2a8" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3a8" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4a8" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5a8" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6a8" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total24"name="num5"></th>
            <th><input type="text" id="1b8" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2b8" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3b8" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4b8" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5b8" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6b8" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total25"name="num5"></th>
            <th><input type="text" id="total.25"name="num5"></th>
            <th><input type="text" id="1c8" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2c8" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3c8" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4c8" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5c8" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6c8" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total26"name="num5"></th>
            <th><input type="text" id="total.26"name="num5"></th>
        </tr>
        <tr>
            <th align="left">Washing of Dishes Done</th>
            <th><input type="text" id="1a9" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2a9" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3a9" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4a9" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5a9" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6a9" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total27"name="num5"></th>
            <th><input type="text" id="1b9" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2b9" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3b9" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4b9" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5b9" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6b9" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total28"name="num5"></th>
            <th><input type="text" id="total.28"name="num5"></th>
            <th><input type="text" id="1c9" name="num1" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="2c9" name="num2" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="3c9" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="4c9" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="5c9" name="num3" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="6c9" name="num4" onkeypress="return add_number(event)"></th>
            <th><input type="text" id="total29"name="num5"></th>
            <th><input type="text" id="total.29"name="num5"></th>
        </tr>
    </table>
  </div>
    <button class="btn" name="submit">Save</button>
    <button class="btn1" name="print">Print</button>
</body>
</php> 