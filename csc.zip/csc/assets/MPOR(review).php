<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MPOReview</title>
    <link rel="stylesheet" href="../style/MPOR(review).css">
    <link rel="stylesheet" href="../style/DORbar.css">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" />
</head>
<body>
    <!--NavBar-->
    <nav>
        <div class="navbar">
          <i class='bx bx-menu'></i>
          <div class="logo"><img src="csc.png" alt=""></div>
          <div class="nav-links">
            <ul class="links">
              <li>
                <a href="DOR.php">DOR</a>
                <i class='bx bxs-chevron-down htmlcss-arrow arrow  '></i>
                <ul class="htmlCss-sub-menu sub-menu">
                               
                  </li>
                </ul>
              <li>
                <a href="MPOR.php">MPOR</a>
                <i class='bx bxs-chevron-down js-arrow arrow '></i>
                <ul class="js-sub-menu sub-menu">
                  
                </ul>
              </li>
              <li>
                <a href="SMPOR.php">SMPOR</a>
                <i class='bx bxs-chevron-down js-arrow arrow '></i>
                <ul class="js-sub-menu sub-menu">
                  
                </ul>
              </li>
              <li>
                <a href="IPCR.php">IPCR</a>
                <i class='bx bxs-chevron-down js-arrow arrow '></i>
                <ul class="js-sub-menu sub-menu">
                  
                </ul>
              </li>
              <li>
                <a href="MPOR(review).php">MPOR (Review)</a>
                <button type="submit" id="Log-out"><a href="logout.php">Log Out</a></button>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </nav>

    <div class="wrapper_3">
        <table border="1px" cellspacing="0" align="center" height="100" width="1400">
            <tr>
                <th align="center" class="th">MONTHLY PERFORMANCE OUTPUT REVIEW
                <form action="" class="form">
                <p align= center style="font-size:15px;">Month of 
                <input type="month" id="qwe" class="input">
                </form>
            </th>
            </tr>
        </table>
    
        
        <div class= "filter">
        <table border="1px" cellspacing="0" align="center" height="300" width="1400">
            <tr>
                <th> </th>
                <th style="font-weight:normal;">Richard</th>
                <th  style="font-weight:normal;">Julie</th>
                <th  style="font-weight:normal;">Yvette</th>
                <th  style="font-weight:normal;">Margie</th>
                <th  style="font-weight:normal;">Christian</th>
                <th  style="font-weight:normal;">Bea</th>
                <th  style="font-weight:normal;">Tonet</th>
                <th  style="font-weight:normal;">Hannah</th>
                <th  style="font-weight:normal;">Angela</th>
                <th  style="font-weight:normal;">Ronel</th>
                <th  style="font-weight:normal;">TOTAL</th>
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">Appointments acted upon</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">S-Cards updated (original appointments)</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">S-Cards updated (not original appointments)</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">Authentication of personnel records acted upon</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">Requests for personnel records acted upon</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">Verification requests sent</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">Test messages sent</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">Customer action(snail mail)* <p style="font-weight:bolder;">RBPMS only</p></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">Walk-in clients</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">Phone-in clients</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">Reports Submitted</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">CSC issuances discussed</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">Requests for documents acted upon</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">Letters prepared</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">Cash advances liquidated</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">Various official functions attended</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">IPCRs of office staff reviewed</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">Resource person assignments rendered</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">e-receipts issued</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">Flag ceremonies attended</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">DTRs submitted</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">MPORs submitted</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">IPS submitted</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
            <tr>
                <th align="left" style="font-weight:normal;">Health and wellness</th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                <th><input type="text" name="asd"></th>
                
            </tr>
        </table>
    
            <table border="1px" cellspacing="0" align="center" height="150" width="1400">
                <tr>
                    <th align="left">Prepared by: </th>
                    <th align="left">Reviewed by: </th>
                </tr>
                <tr>
                    <th><input type="text" id="love" name="lov"> <p><input type="text" id="love" name="pol"></p> </th>
                    <th contenteditable="true">Richard T. Ortiz </th>
                </tr>
           </table>      
    </div>
    </div>
    <button class="btn" name="submit">Save</button>
    <button class="btn1" name="print">Print</button>
    
</body>
</php>